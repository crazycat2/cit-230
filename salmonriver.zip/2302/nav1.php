<h2>
<a href="http://thiscrazycat.com/2302/ra1.php">adventure 1-</a>
<a href="http://thiscrazycat.com/2302/ra2.php">adventure 2-</a>
<a href="http://thiscrazycat.com/2302/ra3.php">adventure 3-</a>
<a href="http://thiscrazycat.com/2302/riverguide.php">river guide-</a>
<a href="http://thiscrazycat.com/2302/registration.php">sign up-</a>
<a href="http://thiscrazycat.com/2302/contact.php">contact</a>
</h2>
<h1 id="cityDisplay">Current Weather Conditions</h1>
<ul id="current_conditions">
<li id="currentTemp"></li>
<li id="summary"></li>
</ul>