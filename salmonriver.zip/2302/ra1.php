<!DOCTYPE html>
<html>
<head>
<title>River Adventure 1</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
</head>

<body>
<header>
</header>
<main>
<h1>River Adevnture 1</h1>
<p>This adventure has many twsits and turns that will surprise and confuse the audience.
<p><h2>Difficuty Level: 1</h2>
<img src="https://s-media-cache-ak0.pinimg.com/236x/46/51/89/4651896c53d6e21db3cf65e7981aa108.jpg">
</main>
<nav>
<?php include 'nav1.php' ?>
</nav>
<footer><?php include 'footer1.php' ?>
</footer>
</body>

</html>