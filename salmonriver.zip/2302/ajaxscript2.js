jQuery(document).ready(function($) {
  $.ajax({
  url : "http:http://api.wunderground.com/api/b71cfa659837e78f/geolookup/q/83549.json",
  dataType : "jsonp",
  success : function(parsed_json) {
  var location = parsed_json['location']['city'];
  var temp_f = parsed_json['current_observation']['temp_f'];
  alert("Current temperature in " + location + " is: " + temp_f);
  }
  });
});