<!DOCTYPE html>
<html>
<head>
<title>Contact Info</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
</head>

<body>
<header>
</header>
<main>
 <h1>Contact Info</h1>
<br>office hours 
|Mon-Wed 11:00am - 5:00pm 
|Sat-Tues 1-6
<br>Phone:768-990-445 Fax:231-768
<br>Adress:3321 Salmon River Rigby Idaho 87869

<p>  
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d255275.08355565328!2d-115.49224515210928!3d45.01644241898849!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x5358158fba1f72dd%3A0xb0a9f6599feec377!2sSalmon+River!5e0!3m2!1sen!2sus!4v1490902456407" width="200" height="200" frameborder="0" style="border:0" allowfullscreen></iframe>
</p>
</main>
<nav>
<?php include 'nav1.php' ?>
</nav>
<footer><?php include 'footer1.php' ?>
</footer>
</body>

</html>