    function getData(lat, long){
		// Get the data from the wunderground API
		$.ajax({

    url:"http://api.wunderground.com/api/b71cfa659837e78f/geolookup/q/83549.json",
    dataType:"jsonp",
    success: function(data){
            var location = data['location']['city'];
            var temp_f = data['current_observation']['temp_f'];
				
                $("cityDisplay").html(location);
                $("currentTemp").html(temp_f);
                alert( "Data Loaded: " + location + temp_f );
			}
               
		});
$("#cover").fadeOut(250);
    }

	// A function for changing a string to TitleCase
	function toTitleCase(str){
		return str.replace(/\w+/g, function(txt){return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
	}

