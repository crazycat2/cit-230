<!DOCTYPE html>
<html>
<head>
<title>River Adventure 3</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
</head>

<body>
<header>
</header>
<main>
<h1>River Adventure 3</h1>
<p>This course has many unxpected turns and changes of events. A few people have gone missing and died. This is for experienced rafters only, who posses a valid rafter's liscense.</p>   
<h2>Difficulty Level 3</h2>
<img src="http://thiscrazycat.com/2302/difficulty.jpg">
</main>
<nav>
<?php include 'nav1.php' ?>
</nav>
<footer><?php include 'footer1.php' ?>
</footer>
</body>

</html>