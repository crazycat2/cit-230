<!DOCTYPE html>
<html>
<head>
<title>Registration</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
</head>

<body>
<header>
</header>
<main>
<h1>Registration</h1>
    
<section id="text-form">
Name:<br>
Email:<br>
Phone:<br>
Age:<br>
Choose Your Adventure:<br>
</section>
    
<section id="text-form2"> 
<form action="/action_page.php">
<input type="text" name="name"><br>
<input type="text" name="email"><br>
<input type="tel" name="usrtel"><br>
<input type="number" name="quantity" min="14" max="100"><br>
<input list="adventuresandtimes">
<datalist id="adventuresandtimes">
  <option value="Adventure 1 12:30pm - 1:30 pm">
  <option value="Adventure 1 1pm - 2pm">
  <option value="Adventure 1 3pm - 4pm">
  <option value="Adventure 2 12:20pm - 1:30pm">
  <option value="Adventure 2 1pm-2pm">
  <option value="Adventure 2 3pm - 4pm">
  <option value="Adventure 3 12:30pm - 1:30pm">
  <option value="Adventure 3 1pm - 2pm">
  <option value="Adventure 3 3pm - 4pm">
</datalist>
<input list="weekdays">
<datalist id="weekdays">
 <option value="mon">
 <option value="tues">
 <option value="wed">
</datalist>
<br>
<input type="submit" value="Submit">
</form>
</section>
    <table>
  <tr>
  	<th></th>
    <th>Adventure 1</th>
    <th>Adventure 2</th> 
    <th>Adventure 3</th>
  </tr>
  <tr>
  	<td>Times</td>
    <td>12:30 - 4:00</td>
    <td>12:30 - 4:00</td>
    <td>12:30 - 4:00</td>
  </tr>
  <tr>
  	<td>Difficulty Level</td>
    <td>1</td>
    <td>2</td>
    <td>3</td>
  </tr>
  <tr>
 	<td>Price</td>
    <td>$10</td>
    <td>$15</td>
    <td>your life</td>
  </tr>
</table>

</main>
<nav>
<?php include 'nav1.php' ?>
</nav>

</body>
<footer><?php include 'footer1.php' ?></footer>
</html>