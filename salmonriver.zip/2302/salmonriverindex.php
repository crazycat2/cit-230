<!DOCTYPE html>
<html>
<head>
<title>index</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
<script src="ajaxscript2.js"></script>
<script src="ajaxscript.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.5.1/jquery.min.js"></script>
<script src="/homework/ajaxthing/jquery-3.1.1.min.js"></script>
<script> 
$(document).ready(function(){
    $("#flip").click(function(){
    $("#panel").slideDown("slow");
    });
});
</script>
</head>

<body>
<header>
</header>
<nav>
<?php include 'nav1.php' ?>
</nav>  
    
<main>
<h1>Welcome to Salmon River Adventures</h1>
<p>Come and experience extraordinary rafting!</p>
<video controls="controls" class="video-ctrl">
<source src="http://thiscrazycat.com/2302/Produce_0.mp4" type="video/mp4">
<source src="http://thiscrazycat.com/2302/Produce_0.avi" type="video/avi">
<source src="http://thiscrazycat.com/2302/Produce_0.webm" type="video/webm">
  Your browser does not support the video tag.
</video>
<iframe width="560" height="315" src="https://www.youtube.com/embed/mJS58vUiJsE" allowfullscreen></iframe>
</main>


<section id="gallery">
<img src="http://3.bp.blogspot.com/-C-LbZXuzbY8/Vp9mw_vl7JI/AAAAAAAAJiI/Z6c7Ko2kw2Q/s1600/descarga%2B%25281%2529.jpg" alt="rafting">
<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/45/Sawtooth_Mountains_and_Salmon_River.JPG/220px-Sawtooth_Mountains_and_Salmon_River.JPG" alt="rafting">
<img src="https://static.wixstatic.com/media/e79a4b_14b2e644734d479a8d6bef37f0769812.jpg_srz_398_249_85_22_0.50_1.20_0.00_jpg_srz" alt="rafting">
</section>

<footer>
<?php include 'footer1.php' ?>
</footer>
</body>

</html>