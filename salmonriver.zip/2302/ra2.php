<!DOCTYPE html>
<html>
<head>
<title>River Adventure 2</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
</head>

<body>
<header>
</header>
<main>
<h1>River Adventure 2</h1>
<p>This advenure is preffred for experienced rafters looking for an easygoing good time.</p>
<p><h2>Difficulty Level:2</h2>
<img src="https://s-media-cache-ak0.pinimg.com/236x/4d/f2/07/4df20793d58ccaf174798dd4e6c1d745.jpg">
</main>
<nav>
<?php include 'nav1.php' ?>
</nav>
<footer><?php include 'footer1.php' ?>
</footer>
</body>

</html>