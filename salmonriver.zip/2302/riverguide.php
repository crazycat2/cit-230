<!DOCTYPE html>
<html>
<head>
<title>River Guides</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width">
<link rel="stylesheet" type="text/css" href="salmonstyle.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
<script> 
$(function(){
		
    $('.dropdownMenu > li').hover(function(){
            //mouseover 
            $(this).children("ul").slideDown(200);
    }, function(){
            //mouseout
            $(this).children("ul").slideUp(200);
    })
})
</script>
</head>

<body>
<header>
</header>
<main>

<ul class="dropdownMenu">
<h1>Our Wonderful River Guides</h1>
<li>1st option
<ul>
<li><img src="https://www.picsofcelebrities.com/media/celebrity/vaughn-lowery/pictures/medium/vaughn-lowery-scandal.jpg" alt="guy-from-jurassic-park"></li>
<li><h2>Dennis</h2><br>He's very trustworthy and reliable. Dennis loves the putdoors and nature. He has a masters in river rafting.</li>
</ul>
</li>
<li>2nd option
<ul>
<li><img src="https://pbs.twimg.com/media/CxhX9kGXAAA08e0.jpg" alt="guy-from-jurassic-park"></li>
<li><h2>Dr.Hammond</h2><br>He has many great ideas. Dr.Hammond is extremely qualified to lead and guide you throughuot your rafting journey. He has a PhD in river rafting.</li>
</ul>
</li>
<li>3rd option
<ul>
<li><img src="https://s-media-cache-ak0.pinimg.com/236x/e5/7c/7d/e57c7d1247d1b7b97a60a1276ecf36cb.jpg" alt="guy-from-jurassic-park"></li>
<li><h2>Indianna Jones - er Dr.Grant</h2><br>He's one who will get you out alive. Certifies and qualified, Dr.Grant is a promising choice as he knows the land better than anyone else.He also has a phD in river rafting.</li>
</ul>
</li>
</ul>
</main>
<nav>
<?php include 'nav1.php' ?>
</nav>
<footer>
<?php include 'footer1.php' ?>
</footer>
</body>

</html>