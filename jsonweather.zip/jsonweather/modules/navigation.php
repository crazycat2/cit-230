<ul class="flexlist">
	<li><a href="/jsonweather/" title="Weather Center Current Location">Current</a></li>
	<li><a href="/jsonweather/views/franklin.php" title="Weather in Franklin, ID">Franklin</a></li>
	<li><a href="/jsonweather/views/greenville.php" title="Weather in Greenville, SC">Greenville</a></li>
	<li><a href="/jsonweather/views/springfield.php" title="Weather in Springfield, IL">Springfield</a></li>
</ul>
