<ul class="flexlist">
	<li>Weather Center 2010 - <?php echo date('Y');  ?></li>
	<li><img src="/jsonweather/images/wulogo_rev.png" alt="Weatherunderground logo" title="All weather data provided by WeatherUnderground.com"></li>
</ul>
