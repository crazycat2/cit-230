<div class="fb-share-button" data-href="http://thiscrazycat.com/" data-layout="button_count" data-size="small" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fthiscrazycat.com%2F&amp;src=sdkpreparse">Share on facebook</a>
</div>

<a data-pin-do="buttonPin" data-pin-round="true" data-pin-save="false" href="https://www.pinterest.com/pin/create/button/?url=http%3A%2F%2Fthiscrazycat.com%2Fhomework%2FWeather_Site%2Ffranklin.php&media=https%3A%2F%2Ffarm8.staticflickr.com%2F7027%2F6851755809_df5b2051c9_z.jpg&description=Next%20stop%3A%20Pinterest"><img src="//assets.pinterest.com/images/pidgets/pinit_fg_en_round_red_16.png" alt="button"/></a>

<a href="https://twitter.com/intent/tweet?button_hashtag=weather" class="twitter-hashtag-button" data-show-count="false">Tweet #weather</a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
    